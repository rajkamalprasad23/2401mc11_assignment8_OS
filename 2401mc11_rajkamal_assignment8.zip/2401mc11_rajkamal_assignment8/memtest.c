#include "types.h"
#include "stat.h"
#include "user.h"

static void
show(char *tag)
{
  struct meminfo mi;

  if(getmeminfo(&mi) < 0){
    printf(1, "getmeminfo failed\n");
    return;
  }

  printf(1, "%s\n", tag);
  printf(1, "total_pages=%d free_pages=%d user_pages=%d page_table_pages=%d\n",
         mi.total_pages, mi.free_pages, mi.user_pages, mi.page_table_pages);
}

int
main(void)
{
  int pid;
  char *p;

  printf(1, "Rajkamal Prasad 2401MC11\n");
  show("Before allocation:");

  p = sbrk(8 * 4096);
  if(p == (char*)-1){
    printf(1, "sbrk failed\n");
    exit();
  }
  p[0] = 1;
  p[7 * 4096] = 2;
  show("After allocation:");

  pid = fork();
  if(pid == 0){
    show("Child:");
    exit();
  }

  wait();
  show("After child is reaped:");

  sbrk(-8 * 4096);
  show("After shrinking:");

  exit();
}
