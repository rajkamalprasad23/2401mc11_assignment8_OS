#include "types.h"
#include "stat.h"
#include "user.h"

int global_value = 10;

int
main(void)
{
  int local_value = 20;
  char *heap = malloc(4096);
  int pid;
  int pa;

  printf(1, "Rajkamal Prasad 2401MC11\n");

  printf(1, "\nGlobal variable:\n");
  printf(1, "VA = %x\n", &global_value);
  pa = va2pa((int)&global_value);
  printf(1, "PA = %x\n", pa);

  printf(1, "\nLocal variable:\n");
  printf(1, "VA = %x\n", &local_value);
  pa = va2pa((int)&local_value);
  printf(1, "PA = %x\n", pa);

  printf(1, "\nHeap allocation:\n");
  printf(1, "VA = %x\n", heap);
  pa = va2pa((int)heap);
  printf(1, "PA = %x\n", pa);

  printf(1, "\nInvalid address:\n");
  printf(1, "VA = 0x7fffffff, PA = %d\n", va2pa(0x7fffffff));

  pid = fork();
  if(pid == 0){
    printf(1, "\nChild:\n");
    printf(1, "VA = %x, PA = %x\n", &global_value,
           va2pa((int)&global_value));
    exit();
  }

  wait();
  printf(1, "\nParent:\n");
  printf(1, "VA = %x, PA = %x\n", &global_value,
         va2pa((int)&global_value));

  free(heap);
  exit();
}
