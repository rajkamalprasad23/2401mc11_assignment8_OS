#include "types.h"
#include "stat.h"
#include "user.h"

static void
show(char *msg)
{
  struct meminfo mi;

  if(getmeminfo(&mi) < 0)
    return;

  printf(1, "%s free_pages=%d user_pages=%d page_tables=%d\n",
         msg, mi.free_pages, mi.user_pages, mi.page_table_pages);
}

int
main(void)
{
  char *p;
  int i;
  int pid;
  char buf[16];

  printf(1, "Rajkamal Prasad 2401MC11\n");

  show("Before sbrk:");
  p = sbrk(32 * 1024 * 1024);
  if(p == (char*)-1){
    printf(1, "large sbrk failed\n");
    exit();
  }
  show("After 32MB sbrk:");

  for(i = 0; i < 32 * 1024 * 1024; i += 4 * 1024 * 1024)
    p[i] = 'x';

  show("After touching selected pages:");

  pid = fork();
  if(pid == 0){
    printf(1, "Child after fork:\n");
    show("Child:");
    exit();
  }
  wait();

  if(read(0, buf, sizeof(buf)) < 0)
    printf(1, "read failed\n");

  show("After child exits:");
  exit();
}
