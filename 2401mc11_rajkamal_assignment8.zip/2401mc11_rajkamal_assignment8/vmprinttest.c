#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  printf(1, "Rajkamal Prasad 2401MC11\n");

  printf(1, "\nInitial page table:\n");
  vmprint();

  printf(1, "\nAfter sbrk(8 pages):\n");
  sbrk(8 * 4096);
  vmprint();

  printf(1, "\nAfter sbrk(-1 page):\n");
  sbrk(-4096);
  vmprint();

  exit();
}
