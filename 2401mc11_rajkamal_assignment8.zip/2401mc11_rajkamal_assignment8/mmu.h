#include "types.h"

#define FL_IF 0x00000200
#define CR0_PE 0x00000001
#define CR0_WP 0x00010000
#define CR0_PG 0x80000000
#define CR4_PSE 0x00000010

#define DPL_USER 0x3
#define SEG_KCODE 1
#define SEG_KDATA 2
#define SEG_UCODE 3
#define SEG_UDATA 4
#define SEG_TSS 5
#define NSEGS 6

#define PDX(va) (((uint)(va) >> PDXSHIFT) & 0x3FF)
#define PTX(va) (((uint)(va) >> PTXSHIFT) & 0x3FF)
#define PGADDR(d,t,o) ((uint)((d)<<PDXSHIFT | (t)<<PTXSHIFT | (o)))

#define NPDENTRIES 1024
#define NPTENTRIES 1024
#define PGSIZE 4096
#define PTXSHIFT 12
#define PDXSHIFT 22
#define PGROUNDUP(sz) (((sz)+PGSIZE-1)&~(PGSIZE-1))
#define PGROUNDDOWN(a) (((a))&~(PGSIZE-1))

#define PTE_P 0x001
#define PTE_W 0x002
#define PTE_U 0x004
#define PTE_PS 0x080
#define PTE_ADDR(pte) ((uint)(pte)&~0xFFF)
#define PTE_FLAGS(pte) ((uint)(pte)&0xFFF)

typedef uint pte_t;
